#ifndef OPS_H
#define OPS_H

int add(int a, int b);

#endif
